const colors = {
  backgroundColor: '#e6e6e6',
  accentColor: '#8d47d3',
  fieldsColor: '#FFFFFF',
  textColor: '#565656',
  buttonColor: '#C8C8C8'
}

export default colors
