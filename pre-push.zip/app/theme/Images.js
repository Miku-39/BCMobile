const images = {
  logo: require('./images/logo.png'),
  hand: require('./images/hand.png'),
  car: require('./images/car1.png'),
  list: require('./images/list.png'),
  wrench: require('./images/wrench.png'),
  boxIn: require('./images/boxIn.png'),
  boxOut: require('./images/boxOut.png'),
  card: require('./images/card.png'),
  sign: require('./images/sign.png')
}

export default images;
